﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
namespace BTL
{
    public partial class DSSach : Form
    {
        public DSSach()
        {
            InitializeComponent();
        }
        int page = 1;
        int totalPage = 0;
        int nItemOnPage = 5;
        int position = 0;
        void setNull()
        {
            tbTensach.Text = "";
            tbTacgia.Text = "";
            tbNXB.Text = "";
            tbID.Text = "";
            tbGia.Text = "0";
            tbPriceTo.Text = "0";
            tbPriceFrom.Text = "0";
            dtpNamXB.Value = DateTime.Now;
            dtpNgayNhap.Value = DateTime.Now;
        }
        void ShowBook(int vitri, int soluong)
        {
            Sach s = new Sach();
            dgvThongTin.DataSource = s.GetListBook(vitri, soluong);
        }
        private void DSSach_Load(object sender, EventArgs e)
        {
            formatTextboxSearch();
            setDateTimePickerDefaultNull();
            btnPrev.Enabled = false;

            Sach s = new Sach();
            totalPage = (int)Math.Ceiling((double)(s.TotalBook() / nItemOnPage));
            ShowBook(position, nItemOnPage);

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            setNull();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            btnLuu.Enabled = false;
            btnHuy.Enabled = false;
            btnThem.Enabled = true;
            btnXoa.Enabled = true;
            btnSua.Enabled = true;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbID.Text != "")
                {
                    DialogResult result = MessageBox.Show("Bạn đang thêm sách đã tồn tại!\nBạn có muốn tiếp tục?",
                        "Thêm sách mới", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (result == DialogResult.Cancel)
                    {
                        setNull();
                        return;
                    }
                }
                Sach s = new Sach();
                s.AddBook(
                     tbTensach.Text,
                     tbTacgia.Text,
                     dtpNamXB.Value.ToShortDateString(),
                     tbNXB.Text,
                     tbGia.Text,
                     dtpNgayNhap.Value.ToShortDateString()
                 );
                ShowBook(position, nItemOnPage);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,
                       "Thêm sách mới", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void formatTextboxSearch()
        {
            tbKeyword.Text = "Nhập tên sách, tác giả hoặc nhà xuất bản";
            tbKeyword.ForeColor = Color.DarkGray;
        }
        private void setDateTimePickerDefaultNull()
        {
            dtpSearchNgayNhapFrom.Format = DateTimePickerFormat.Custom;
            dtpSearchNgayNhapFrom.CustomFormat = " ";

            dtpSearchNgayNhapTo.Format = DateTimePickerFormat.Custom;
            dtpSearchNgayNhapTo.CustomFormat = " ";

            dtpSearchNXBFrom.Format = DateTimePickerFormat.Custom;
            dtpSearchNXBFrom.CustomFormat = " ";

            dtpSearchNXBTo.Format = DateTimePickerFormat.Custom;
            dtpSearchNXBTo.CustomFormat = " ";
        }
        
        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbID.Text == "" || tbID.Text == "0")
                {
                    MessageBox.Show("Vui lòng chọn sách cần xóa", "Xóa sách");
                    return;
                }
                if (dgvThongTin.SelectedCells.Count > 0)
                {
                    Sach d = new Sach();
                    if (d.CheckBookExistInChiTietPhieuMuon(int.Parse(tbID.Text)))
                    {
                        MessageBox.Show(
                            "Không thể xóa!\nSách đã tồn tại trong phiếu mượn",
                            "Xóa sách",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
                        return;
                    }
                    DialogResult dr = MessageBox.Show("Bạn có chắc xóa sách " + tbTensach.Text + " không?", "Xóa sách", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (dr == DialogResult.OK)
                    {
                        d.DeleteBook(int.Parse(tbID.Text));
                        ShowBook(position, nItemOnPage);
                        setNull();
                    }
                }
                else MessageBox.Show("Vui lòng chọn sách cần xóa");
            }
            catch(Exception ex)
            {
                MessageBox.Show(
                            ex.Message,
                            "Xóa sách",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (tbID.Text == "" || tbID.Text == "0")
            {
                MessageBox.Show("Vui lòng chọn sách cần cập nhật", "Sửa thông tin sách", MessageBoxButtons.OK);
                return;
            }
            btnLuu.Enabled = true;
            btnHuy.Enabled = true;
            btnThem.Enabled = false;
            btnXoa.Enabled = false;
            btnSua.Enabled = false;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvThongTin.SelectedCells.Count > 0)
                {
                    Sach d = new Sach();
                    d.UpdateBook(
                        Int16.Parse(tbID.Text),
                        tbTensach.Text,
                        tbTacgia.Text,
                        dtpNamXB.Value.ToShortDateString(),
                        tbNXB.Text,
                        tbGia.Text,
                        dtpNgayNhap.Value.ToShortDateString()
                    );
                    ShowBook(position, nItemOnPage);
                    btnLuu.Enabled = false;
                    btnHuy.Enabled = false;
                    btnThem.Enabled = true;
                    btnXoa.Enabled = true;
                    btnSua.Enabled = true;
                }
                else MessageBox.Show("Vui lòng chọn sách cần sửa", "Sửa thông tin sách");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Sửa thông tin sách", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbKeyword_Enter(object sender, EventArgs e)
        {
            if (tbKeyword.Text == "Nhập tên sách, tác giả hoặc nhà xuất bản")
            {
                tbKeyword.Text = "";
                tbKeyword.ForeColor = Color.Black;
            }
        }

        private void tbKeyword_Leave(object sender, EventArgs e)
        {
            if (tbKeyword.Text == "")
            {
                tbKeyword.Text = "Nhập tên sách, tác giả hoặc nhà xuất bản";
                tbKeyword.ForeColor = Color.DarkGray;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string keyword = "";
                string namXBFrom = "";
                string namXBTo = "";
                double giaFrom = -1;
                double giaTo = -1;
                string ngayNhapFrom = "";
                string ngayNhapTo = "";
                if (tbKeyword.Text != "Nhập tên sách, tác giả hoặc nhà xuất bản")
                {
                    keyword = tbKeyword.Text;
                }

                if (tbPriceFrom.Text != "0" || tbPriceTo.Text != "0")
                {
                    giaFrom = double.Parse(tbPriceFrom.Text);
                    giaTo = double.Parse(tbPriceTo.Text);
                }

                if (dtpSearchNXBFrom.Text != " ")
                    namXBFrom = dtpSearchNXBFrom.Value.ToShortDateString();

                if (dtpSearchNXBFrom.Text == " ") namXBTo = DateTime.Now.ToString("dd/MM/yyyy");
                else namXBTo = dtpSearchNXBTo.Value.ToShortDateString();

                if (dtpSearchNgayNhapFrom.Text != " ")
                    ngayNhapFrom = dtpSearchNgayNhapFrom.Value.ToShortDateString();

                if (dtpSearchNgayNhapTo.Text == " ") ngayNhapTo = DateTime.Now.ToString("dd/MM/yyyy");
                else ngayNhapTo = dtpSearchNgayNhapTo.Value.ToShortDateString();

                //Debug.WriteLine(namXBFrom);

                dgvThongTin.Refresh();
                Sach s = new Sach();
                IEnumerable<SACH> sach = s.FindBook(keyword, namXBFrom, namXBTo, giaFrom, giaTo, ngayNhapFrom, ngayNhapTo);
                dgvThongTin.DataSource = sach.ToList();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Tìm kiếm sách",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dtpSearchNgayNhapFrom_ValueChanged(object sender, EventArgs e)
        {
            DateTimePicker d = sender as DateTimePicker;
            d.CustomFormat = "dd/MM/yyyy";
        }

        private void btnTry_Click(object sender, EventArgs e)
        {
            formatTextboxSearch();
            setDateTimePickerDefaultNull();
            tbPriceFrom.Text = "0";
            tbPriceTo.Text = "0";
            ShowBook(position, nItemOnPage);
        }

        private void dgvThongTin_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int numrow = e.RowIndex;
                if (numrow >= 0)
                {
                    tbID.Text = dgvThongTin.Rows[numrow].Cells[0].Value.ToString();
                    tbTensach.Text = dgvThongTin.Rows[numrow].Cells[1].Value != null ? dgvThongTin.Rows[numrow].Cells[1].Value.ToString() : "";
                    tbTacgia.Text = dgvThongTin.Rows[numrow].Cells[2].Value != null ? dgvThongTin.Rows[numrow].Cells[2].Value.ToString() : "";
                    dtpNamXB.Text = dgvThongTin.Rows[numrow].Cells[3].Value != null ? dgvThongTin.Rows[numrow].Cells[3].Value.ToString() : "";
                    tbNXB.Text = dgvThongTin.Rows[numrow].Cells[4].Value != null ? dgvThongTin.Rows[numrow].Cells[4].Value.ToString() : "";
                    tbGia.Text = dgvThongTin.Rows[numrow].Cells[5].Value != null ? dgvThongTin.Rows[numrow].Cells[5].Value.ToString() : "";
                    dtpNgayNhap.Text = dgvThongTin.Rows[numrow].Cells[6].Value != null ? dgvThongTin.Rows[numrow].Cells[6].Value.ToString() : "";

                    btnSua.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Sách",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void setButton()
        {
            if (page == 1) btnPrev.Enabled = false;
            else btnPrev.Enabled = true;

            if (page > totalPage) btnNext.Enabled = false;
            else btnNext.Enabled = true;
        }
        int vitri(int page, int nRecord)
        {
            return (page - 1) * nRecord;
        }
        private void btnPrev_Click(object sender, EventArgs e)
        {
            
            if (page > 1)
            {
                page -= 1;
                setButton();
                position = vitri(page, nItemOnPage);
                ShowBook(position, nItemOnPage);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (page <= totalPage)
            {
                page += 1;
                setButton();
                position = vitri(page, nItemOnPage);
                ShowBook(position, nItemOnPage);
            }
        }
    }
}
